/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arcadeoptiongame.Classes;

import java.util.Random;
import javax.swing.Icon;

/**
 *
 * @author Studio20-10
 */
public class Treasure {

    private int treasure;
    private Icon icon;

    public Treasure() {

    }

    public Icon chooseIcon(int num) {

        switch (num) {
            case 1:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/swordimg.jpg")));
                break;
            case 2:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/potionimg.png")));
                break;
            case 3:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/goldimg.jpg")));
                break;
            case 4:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/armorimg.jpg")));
                break;
            case 5:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/shoeimg.png")));
                break;
            case 6:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/muscleimg.jpg")));
                break;
            case 7:
                setIcon(new javax.swing.ImageIcon(getClass().getResource("/arcadeoptiongame/Images/gloveimg.png")));
                break;
        }

        return getIcon();
    }

    public int getTreasure() {
        return treasure;
    }

    public void setTreasure(int treasure) {
        this.treasure = treasure;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }

    public void randomTreasure() {
        Random rand = new Random();

        //rand.nextInt(max - min + 1) + min;
        setTreasure(rand.nextInt(7 - 1 + 1) + 1);
    }
}
