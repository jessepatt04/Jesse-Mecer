/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arcadeoptiongame.Classes;

import javax.swing.Icon;

/**
 *
 * @author Studio20-10
 */
public class Enemy {

    private Icon icon;
    private int health, damage;
    private boolean Special = false;
    private String[] specialArr;

    public String[] getSpecialArr() {
        return specialArr;
    }

    public void setSpecialArr(String[] specialArr) {
        this.specialArr = specialArr;
    }

    public boolean isSpecial() {
        return Special;
    }

    public void setSpecial(boolean Special) {
        this.Special = Special;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }

    public Enemy() {
    }

    public void specialMoves(String txt) {

        String[] strArr = txt.split("#");
        String[] special = new String[strArr.length + 4];
        special[strArr.length] = "Normal";
        special[strArr.length + 1] = "Normal";
        special[strArr.length + 2] = "Normal";
        special[strArr.length + 3] = "Normal";
        for (int i = 0; i < strArr.length; i++) {
            switch (strArr[i]) {//Special moves place here
                case "1":
                    special[i] = "ReduceDamage";
                    break;
                case "2":
                    special[i] = "BigAttack";
                    break;
                case "3":
                    special[i] = "Sleep";
                    break;    
            }
        }
        setSpecialArr(special);

    }

}
