/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arcadeoptiongame.Classes;

/**
 *
 * @author Studio20-10
 */
public class Character {

    private int health = 100, damage = 1, gold = 0, room = 0,points=0;
    private double dodge = 5.5, tackle = 4.0, parry = 4.0, stab = 4.0;
    
    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public double getStab() {
        return stab;
    }

    public void setStab(double stab) {
        this.stab = stab;
    }

    public double getDodge() {
        return dodge;
    }

    public void setDodge(double dodge) {
        this.dodge = dodge;
    }

    public double getTackle() {
        return tackle;
    }

    public void setTackle(double tackle) {
        this.tackle = tackle;
    }

    public double getParry() {
        return parry;
    }

    public void setParry(double parry) {
        this.parry = parry;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

}
