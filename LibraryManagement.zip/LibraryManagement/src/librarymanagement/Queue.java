//Jesse A P
package librarymanagement;

import java.util.ArrayList;

/**
 *
 * @author Studio20-10
 */
public class Queue extends Book {

    private ArrayList<String> peopleList;

    public Queue(String b) {//Main constructor
        super(b);
        peopleList = new ArrayList<>();
    }

    public ArrayList<String> getPeopleList() {
        return peopleList;
    }

    public void setPeopleList(ArrayList<String> peopleList) {
        this.peopleList = peopleList;
    }

    public void checkQueue(String user) throws DuplicateUserException {//Checks if user is in queue already     
            if (peopleList.contains(user)) {
                throw new DuplicateUserException();
            } 
    }

    public void addQueue(String user) throws DuplicateUserException {//adds to queue
        checkQueue(user);
        peopleList.add(user);
    }

    public void removeQueue() {//removes first person in queue
        peopleList.remove(0);
    }

    public String getFirstQueue() {//Get first person in queue
        return peopleList.get(0);
    }

    public boolean containsQueue(String user) {//checks if you are in queue
        return peopleList.contains(user);
    }

    @Override
    public String toString() {
        StringBuilder text = new StringBuilder("");
        for (String user : peopleList) {
            text.append("#");
            text.append(user);
        }
        return getBook() + text;
    }

}
