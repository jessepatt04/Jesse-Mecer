//Jesse A P
package librarymanagement;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import static librarymanagement.LibraryManagement.getConn;

/**
 *
 * @author Studio20-10
 */
public final class QueueFrame extends javax.swing.JFrame {

    private final User user;
    private final ArrayList<Queue> queueList = new ArrayList<>();
    private static Connection conn;

    /**
     * Creates new form QueueFrame
     */
    public QueueFrame(User user) {
        this.user = user;
        QueueFrame.conn = getConn();
        initComponents();
        panelQueue.setBackground(user.getUserColor());
        setArea();
    }

    private void setArea() {//Display method
        txtArea.setText("");
        int i = 1;
        File queueFile = new File("Queue.txt");
        try {
            Scanner scQueue = new Scanner(queueFile);
            while (scQueue.hasNext()) {
                int j = 1;
                Scanner sc = new Scanner(scQueue.nextLine()).useDelimiter("#");
                txtArea.append(i + ": " + sc.next() + "\n");//Displays
                while (sc.hasNext()) {
                    txtArea.append("\t" + j + ": " + sc.next() + "\n");
                    j++;
                }
                i++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void addQueue() {//When user joins que
        if (!txtQueue.getText().isEmpty()) {
            ArrayList<Book> arrList = new ArrayList<>();
            File queueFile = new File("Queue.txt");
            int test = 0;
            try {
                Scanner scQueue = new Scanner(queueFile);

                while (scQueue.hasNext()) {//Scan queue file and stores in queuelist
                    Scanner sc = new Scanner(scQueue.nextLine()).useDelimiter("#");
                    String bookName = sc.next();
                    queueList.add(new Queue(bookName));
                    while (sc.hasNext()) {
                        String temp = sc.next();
                        queueList.get(test).addQueue(temp);
                    }
                    test++;
                    sc.close();
                }
                scQueue.close();

                int opt = Integer.parseInt(txtQueue.getText());//Get user input
                txtQueue.setText("");
                if (!queueList.get(opt - 1).containsQueue(user.getName())) {//Does user exist in que?
                    try {
                        PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = \"" + user.getName() + "\"");
                        ResultSet rs = pstmt.executeQuery();
                        if (rs.next()) {

                            File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));
                            Scanner scFile = new Scanner(userFile);//Gets user file and stores in arrlist
                            while (scFile.hasNext()) {
                                Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");//Scans user file stores in arrList
                                String strbook = sc.next();
                                DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                LocalDate date = LocalDate.parse(sc.next(), format);
                                boolean pay = sc.nextBoolean();
                                Book bookObj = new Book(strbook, date, pay);
                                arrList.add(bookObj);
                                sc.close();
                            }
                            scFile.close();
                            boolean contains = false;
                            for (int i = 0; i < arrList.size() && contains == false; i++) {
                                if (arrList.get(i).getBook().equals(queueList.get(opt - 1).getBook())) {
                                //Checks if user is the owner of the book user chose to join que 
                                    contains = true;
                                }
                            }
                            if (!contains) {//If you dont own book
                                queueList.get(opt - 1).addQueue(user.getName());
                            } else {
                                JOptionPane.showMessageDialog(null, "You are the owner of the book");
                            }
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(QueueFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "You are already in queue");
                }

                FileWriter fwQueue = new FileWriter(queueFile);//Writes change into que file
                for (int i = 0; i < queueList.size(); i++) {
                    fwQueue.write(queueList.get(i).toString());
                    fwQueue.write("\n");
                }
                fwQueue.close();

            } catch (FileNotFoundException ex) {
                Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DuplicateUserException ex) {
                System.out.println("Error!");
            }
            queueList.clear();
            setArea();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelQueue = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        btnJoin = new javax.swing.JButton();
        txtQueue = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        jLabel1.setText("Used Books");

        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        btnJoin.setText("Join Queue");
        btnJoin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJoinActionPerformed(evt);
            }
        });

        txtQueue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtQueueKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout panelQueueLayout = new javax.swing.GroupLayout(panelQueue);
        panelQueue.setLayout(panelQueueLayout);
        panelQueueLayout.setHorizontalGroup(
            panelQueueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelQueueLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelQueueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelQueueLayout.createSequentialGroup()
                        .addComponent(btnJoin)
                        .addGap(18, 18, 18)
                        .addComponent(txtQueue, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 126, Short.MAX_VALUE)
                        .addComponent(btnBack))
                    .addGroup(panelQueueLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelQueueLayout.setVerticalGroup(
            panelQueueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelQueueLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(panelQueueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                    .addComponent(btnJoin)
                    .addComponent(txtQueue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelQueue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelQueue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBookFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnJoinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJoinActionPerformed
        addQueue();
    }//GEN-LAST:event_btnJoinActionPerformed

    private void txtQueueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtQueueKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            addQueue();
        }
    }//GEN-LAST:event_txtQueueKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnJoin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelQueue;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JTextField txtQueue;
    // End of variables declaration//GEN-END:variables
}
