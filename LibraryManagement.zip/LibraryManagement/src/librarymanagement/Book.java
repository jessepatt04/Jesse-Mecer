//Jesse A P
package librarymanagement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Studio20-10
 */
public class Book implements Comparable<Book>{

    private String book;
    private LocalDate date = LocalDate.now().plusWeeks(1);
    private boolean payment = false;

    public Book(String b, LocalDate ld, boolean p) {//Used for pre existing books in user file
        this.book = b;
        this.date = ld;
        this.payment = p;
    }

    public Book(String b) {//Used for new books from book file
        this.book = b;
    }
    
    @Override
    public int compareTo(Book other){//Compares book obj by the name
    return this.getBook().compareTo(other.getBook());
    }
    
    public static void sorter(ArrayList<Book> arrList){//Static sorter to be used in all classes in namespace
    Collections.sort(arrList);
    }
    
//Mutators and Accessors

    public String getBook() {
        return book;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public boolean isPayment() {
        return payment;
    }

    public void setPayment(boolean payment) {
        this.payment = payment;
    }

    public String toString() {

        return book + "#" + date + "#" + payment;
    }

}
