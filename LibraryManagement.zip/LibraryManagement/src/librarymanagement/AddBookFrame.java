//Jesse A P
package librarymanagement;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static librarymanagement.LibraryManagement.getConn;

/**
 *
 * @author Studio20-10
 */
public final class AddBookFrame extends javax.swing.JFrame {

    private static Connection conn;
    private final User user;
    private final ArrayList<Book> arrList = new ArrayList<>();
    private final ArrayList<Queue> queueList = new ArrayList<>();

    /**
     * Creates new form AddBookFrame
     */
    public AddBookFrame(User user) {
        this.user = user;
        AddBookFrame.conn = getConn();//Static Connection
        initComponents();
        panelAdd.setBackground(user.getUserColor());
        setArea();//Set the text area to display books available in library
    }

    private void setArea() {
        int i = 1;
        File bookFile = new File("Book.txt");
        try {
            Scanner scBook = new Scanner(bookFile);
            while (scBook.hasNext()) {
                Scanner sc = new Scanner(scBook.nextLine()).useDelimiter("#");
                txtArea.append(i + ": " + sc.next() + "\n");//Displays
                i++;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void addBook() throws LibraryOutOfBoundsException {
        ArrayList<Book> bookArr = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();//Gets user txt file from db
            if (rs.next() && !txtField.getText().isEmpty()) {

                File bookFile = new File("Book.txt");
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));

                Scanner scFile = new Scanner(userFile);//Scans Userfile and stores info in arrList
                while (scFile.hasNext()) {
                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");
                    String book = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    Book newBook = new Book(book, date, pay);
                    arrList.add(newBook);
                }
                scFile.close();
                if (arrList.size() < 5) {//Can not be more than 5 books per user
                    Scanner scBook = new Scanner(bookFile);//Scans book file and store in bookArr
                    while (scBook.hasNext()) {
                        Scanner sc = new Scanner(scBook.nextLine()).useDelimiter("#");
                        String book = sc.next();
                        Book newBook = new Book(book);
                        bookArr.add(newBook);
                    }
                    int opt = Integer.parseInt(txtField.getText());

                    if (opt > bookArr.size()) {
                        throw new LibraryOutOfBoundsException(opt);
                    }

                    arrList.add(bookArr.get(opt - 1));//Adds chosen book to user txt
                    addQueue(bookArr.get(opt - 1).getBook());//Adds book to queue
                    bookArr.remove(opt - 1);//Removes chosen book from library
                    scBook.close();

                    FileWriter fwBook = new FileWriter(bookFile);//Writes changes into files
                    for (int i = 0; i < bookArr.size(); i++) {
                        fwBook.write(bookArr.get(i).getBook());
                        fwBook.write("\n");
                    }
                    fwBook.close();
                } else {
                    JOptionPane.showMessageDialog(null, "Max Capacity");
                }

                Book.sorter(arrList);//Sorts before changes are written in user file (sorts by name)

                FileWriter fwFile = new FileWriter(userFile);//Writes changes in file
                for (int i = 0; i < arrList.size(); i++) {
                    fwFile.write(arrList.get(i).toString());
                    fwFile.write("\n");
                }
                fwFile.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }

    private void addQueue(String newQue) {
        int test = 0;
        boolean found = false;
        File queueFile = new File("Queue.txt");
        try {
            Scanner scQueue = new Scanner(queueFile);

            while (scQueue.hasNext()) {//Scans que file saves in queueList
                Scanner sc = new Scanner(scQueue.nextLine()).useDelimiter("#");
                String bookName = sc.next();
                queueList.add(new Queue(bookName));
                while (sc.hasNext()) {
                    String temp = sc.next();
                    queueList.get(test).addQueue(temp);
                }
                test++;
                sc.close();
            }
            scQueue.close();

            for (int i = 0; i < queueList.size() && found == false; i++) {//Checks if its exists in quelist
                if (queueList.get(i).getBook().equals(newQue)) {
                    found = true;
                }
            }

            if (!found) {
                queueList.add(new Queue(newQue));//Adds it
            }

            FileWriter fwQueue = new FileWriter(queueFile);//Saves changes
            for (int i = 0; i < queueList.size(); i++) {
                fwQueue.write(queueList.get(i).toString());
                fwQueue.write("\n");
            }
            fwQueue.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DuplicateUserException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelAdd = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        txtField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnQueue = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelAdd.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setText("Add a Book");

        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        txtField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtFieldKeyPressed(evt);
            }
        });

        jLabel2.setText("Add:");

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnQueue.setText("Queue");
        btnQueue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQueueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelAddLayout = new javax.swing.GroupLayout(panelAdd);
        panelAdd.setLayout(panelAddLayout);
        panelAddLayout.setHorizontalGroup(
            panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAddLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(txtField, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnAdd)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnQueue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(btnBack)
                .addContainerGap())
            .addGroup(panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelAddLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(63, Short.MAX_VALUE)))
        );
        panelAddLayout.setVerticalGroup(
            panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAddLayout.createSequentialGroup()
                .addContainerGap(331, Short.MAX_VALUE)
                .addGroup(panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                    .addComponent(txtField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd)
                    .addComponent(btnQueue))
                .addContainerGap())
            .addGroup(panelAddLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelAddLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel2)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFieldKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER && !txtField.getText().isEmpty()) {
            try {
                addBook();
            } catch (LibraryOutOfBoundsException ex) {
                Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_txtFieldKeyPressed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        try {
            addBook();
        } catch (LibraryOutOfBoundsException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnQueueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQueueActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QueueFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }//GEN-LAST:event_btnQueueActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnQueue;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelAdd;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JTextField txtField;
    // End of variables declaration//GEN-END:variables
}
