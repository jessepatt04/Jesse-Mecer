/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagement;

/**
 *
 * @author Studio20-10
 */
public class Author extends Book{
    private String author;
    
    public Author(String b, String a){
    super(b);
    this.author = a;
    }

    @Override
    public String getAuthor() {
        return author;
    }

    @Override
    public void setAuthor(String author) {
        this.author = author;
    }
    
    @Override
    public String toString(){
    return getBook() + " > " + author;
    }
}
