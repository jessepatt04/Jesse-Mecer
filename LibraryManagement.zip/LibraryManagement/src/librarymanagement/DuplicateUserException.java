/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagement;

import javax.swing.JOptionPane;

/**
 *
 * @author Studio20-10
 */
public class DuplicateUserException extends Exception{
    public DuplicateUserException(){//Already in que check
    JOptionPane.showMessageDialog(null, "You already queued");
    }
}
