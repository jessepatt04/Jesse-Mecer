/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagement;

import javax.swing.JOptionPane;

/**
 *
 * @author Studio20-10
 */
public class LibraryOutOfBoundsException extends Exception{
    public LibraryOutOfBoundsException(int choice){//Out of bounds check
    JOptionPane.showMessageDialog(null, choice+ "Out of bounds");
    }
}
