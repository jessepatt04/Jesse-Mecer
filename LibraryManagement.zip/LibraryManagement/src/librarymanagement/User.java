//Jesse A P
package librarymanagement;

import java.awt.Color;

/**
 *
 * @author Studio20-10
 */
public class User {
    private String name;
    private double money;
    private Color userColor;
    
    public User(){}//Default
    
    public User(String name){//Main constructor
    this.name = name;
    }
    
    public User(String name, Color userColor, double money){
    this.name = name;
    this.userColor = userColor;
    this.money = money;
    }

    public Color getUserColor() {
        return userColor;
    }

    public void setUserColor(Color userColor) {
        this.userColor = userColor;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
