//Jesse A P
package librarymanagement;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static librarymanagement.LibraryManagement.getConn;

/**
 *
 * @author Studio20-10
 */
public final class BookFrame extends javax.swing.JFrame {

    private static Connection conn;
    private final User user;
    private final ArrayList<Book> arrList = new ArrayList<>();
    private final ArrayList<Queue> queueList = new ArrayList<>();

    /**
     * Creates new form BookFrame
     */
    public BookFrame(User user) {
        this.user = user;
        BookFrame.conn = getConn();//Static Connection
        initComponents();
        panelBook.setBackground(user.getUserColor());
        validateDueDate();//Checks due date
        setLabels();//Sets label to display hired books
    }

    private void validateDueDate() {
        ArrayList<Book> bookArr = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));
                File bookFile = new File("Book.txt");

                if (!userFile.exists()) {//Sets up new txt file if it dosent exist
                    FileWriter fwNew = new FileWriter(userFile);
                    fwNew.close();
                }

                Scanner scFile = new Scanner(userFile);

                for (int i = 0; i < 5 && scFile.hasNext(); i++) {

                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");//Scans user file stores in arrList
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    String uri = sc.next();
                    Book bookObj = new Book(strbook, date, pay,uri);
                    arrList.add(bookObj);

                    if (bookObj.getDate().isBefore(LocalDate.now())) {//Checks date
                        JOptionPane.showMessageDialog(null, bookObj.getBook() + " was removed for out of date reasoning " + bookObj.getDate());
                        Scanner scBook = new Scanner(bookFile);

                        while (scBook.hasNext()) {//Scans book file stores in bookArr
                            Scanner scLine = new Scanner(scBook.nextLine());
                            Book newBook = new Book(scLine.next());
                            bookArr.add(newBook);
                        }
                        scBook.close();

                        if (removeQueue(bookObj.getBook())) {//Checks Queue
                            bookArr.add(bookObj);//Adds to library and removes from user file
                        }
                        arrList.remove(bookObj);

                        FileWriter fwBook = new FileWriter(bookFile);
                        for (int j = 0; j < bookArr.size(); j++) {//Writes changes into book File
                            fwBook.write(bookArr.get(j).getBook());
                            fwBook.write("\n");
                        }
                        fwBook.close();
                    }
                }
                FileWriter fwFile = new FileWriter(userFile);
                for (int j = 0; j < arrList.size(); j++) {//Writes changes into user file
                    fwFile.write(arrList.get(j).toString());
                    fwFile.write("\n");
                }
                fwFile.close();
                scFile.close();

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setLabels() {

        String[] arr = {"", "", "", "", ""};
        boolean[] bool = {false, false, false, false, false};

        lblLink1.setVisible(bool[0]);
        lblLink2.setVisible(bool[1]);
        lblLink3.setVisible(bool[2]);
        lblLink4.setVisible(bool[3]);
        lblLink5.setVisible(bool[4]);
        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));

                Scanner scFile = new Scanner(userFile);

                for (int i = 0; i < 5 && scFile.hasNext(); i++) {

                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");
                    //Scans user file and stores in a String array
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    String uri = sc.next();
                    Book bookObj = new Book(strbook, date, pay,uri);
                    arr[i] = bookObj.getBook() + "     Due: " + bookObj.getDate();
                    bool[i] = bookObj.isPayment();
                    sc.close();

                }

                lblBook1.setText("1: " + arr[0]);//Display
                lblBook2.setText("2: " + arr[1]);
                lblBook3.setText("3: " + arr[2]);
                lblBook4.setText("4: " + arr[3]);
                lblBook5.setText("5: " + arr[4]);

                lblLink1.setVisible(bool[0]);
                lblLink2.setVisible(bool[1]);
                lblLink3.setVisible(bool[2]);
                lblLink4.setVisible(bool[3]);
                lblLink5.setVisible(bool[4]);
                
                setLinks(bool);

                scFile.close();

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void setLinks(boolean[] bool) {
        if (bool[0]) {
            lblLink1.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    try {
                        Desktop.getDesktop().browse(new URI(arrList.get(0).getURI()));
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        } if (bool[1]) {
            lblLink2.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    try {
                        Desktop.getDesktop().browse(new URI(arrList.get(1).getURI()));
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        } if (bool[2]) {
            lblLink3.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    try {
                        Desktop.getDesktop().browse(new URI(arrList.get(2).getURI()));
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        } if (bool[3]) {
            lblLink4.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    try {
                        Desktop.getDesktop().browse(new URI(arrList.get(3).getURI()));
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        } if (bool[4]) {
            lblLink5.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e){
                    try {
                        Desktop.getDesktop().browse(new URI(arrList.get(4).getURI()));
                    } catch (URISyntaxException | IOException ex) {
                        Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }
    }

    private boolean removeQueue(String removeQue) {
        int test = 0;
        boolean found = false;
        boolean mainBoolean = false;
        File queueFile = new File("Queue.txt");
        ArrayList<Book> newArrList = new ArrayList<>();
        try {
            Scanner scQueue = new Scanner(queueFile);

            while (scQueue.hasNext()) {//Scan que file and stores in queuelist
                Scanner sc = new Scanner(scQueue.nextLine()).useDelimiter("#");
                String bookName = sc.next();
                queueList.add(new Queue(bookName));
                while (sc.hasNext()) {
                    String temp = sc.next();
                    queueList.get(test).addQueue(temp);
                }
                test++;
                sc.close();
            }
            scQueue.close();

            for (int i = 0; i < queueList.size() && found == false; i++) {
                //Loops queuelist to find the book user is removing
                if (queueList.get(i).getBook().equals(removeQue)) {
                    found = true;
                    if (!queueList.get(i).getPeopleList().isEmpty()) {//If there is a que

                        PreparedStatement newPstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = \"" + queueList.get(i).getFirstQueue() + "\"");
                        ResultSet rs = newPstmt.executeQuery();
                        if (rs.next()) {
                            File newUserFile = new File("TextFiles\\" + rs.getString("BooksFile"));
                            try {
                                Scanner scFile = new Scanner(newUserFile);
                                while (scFile.hasNext()) {//Scan through the file of the first person in queue
                                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");//Scans user file stores in arrList
                                    String strbook = sc.next();
                                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                    LocalDate date = LocalDate.parse(sc.next(), format);
                                    boolean pay = sc.nextBoolean();
                                    String uri = sc.next();
                                    Book bookObj = new Book(strbook, date, pay, uri);
                                    newArrList.add(bookObj);//Strores in newArrList
                                    sc.close();
                                }
                                scFile.close();

                                if (newArrList.size() < 5) {//If they have space they will get the book
                                    newArrList.add(new Book(queueList.get(i).getBook()));
                                } else {//If not they are removed from que and tries again
                                    queueList.get(i).removeQueue();
                                    FileWriter fwQueue = new FileWriter(queueFile);
                                    for (int j = 0; j < queueList.size(); j++) {
                                        fwQueue.write(queueList.get(j).toString());
                                        fwQueue.write("\n");
                                    }
                                    fwQueue.close();
                                    queueList.clear();
                                    return removeQueue(removeQue);//Recursion to repeat method until decision is made
                                }

                                FileWriter fwFile = new FileWriter(newUserFile);//Saves first person in que change
                                for (int j = 0; j < newArrList.size(); j++) {
                                    fwFile.write(newArrList.get(j).toString());
                                    fwFile.write("\n");
                                }
                                fwFile.close();
                                newArrList.clear();
                            } catch (FileNotFoundException e) {
                                System.out.println("No File");
                            } catch (IOException e) {
                                System.out.println("IO Error");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Result set was empty");
                        }
                        queueList.get(i).removeQueue();//Once first person in que gets book they are removed from que
                    } else {//If no que remove book from que and return true to add book to library
                        queueList.remove(i);
                        mainBoolean = true;
                    }
                }
            }
            FileWriter fwQueue = new FileWriter(queueFile);//Save changes of que
            for (int i = 0; i < queueList.size(); i++) {
                fwQueue.write(queueList.get(i).toString());
                fwQueue.write("\n");
            }
            fwQueue.close();
            queueList.clear();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DuplicateUserException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        return mainBoolean;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     *
     * public void mouseClicked(MouseEvent e){ try{
     * Desktop.getDesktop().browse(new URI("https://en.wikipedia.org"));
     * }catch(Exception ex){ ex.printStackTrace(); } }
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBook = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblBook1 = new javax.swing.JLabel();
        lblBook2 = new javax.swing.JLabel();
        lblBook3 = new javax.swing.JLabel();
        lblBook4 = new javax.swing.JLabel();
        lblBook5 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblLink1 = new javax.swing.JLabel();
        lblLink2 = new javax.swing.JLabel();
        lblLink3 = new javax.swing.JLabel();
        lblLink4 = new javax.swing.JLabel();
        lblLink5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelBook.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setText("Books you own");

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        lblLink1.setText("Visit");

        lblLink2.setText("Visit");

        lblLink3.setText("Visit");

        lblLink4.setText("Visit");

        lblLink5.setText("Visit");

        javax.swing.GroupLayout panelBookLayout = new javax.swing.GroupLayout(panelBook);
        panelBook.setLayout(panelBookLayout);
        panelBookLayout.setHorizontalGroup(
            panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBookLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBookLayout.createSequentialGroup()
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblBook3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(lblBook4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblBook5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblBook2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblBook1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblLink2)
                            .addComponent(lblLink3)
                            .addComponent(lblLink4)
                            .addComponent(lblLink5)
                            .addComponent(lblLink1))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panelBookLayout.createSequentialGroup()
                        .addComponent(btnAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnRemove)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBack)))
                .addContainerGap())
            .addGroup(panelBookLayout.createSequentialGroup()
                .addGap(172, 172, 172)
                .addComponent(jLabel1)
                .addContainerGap(180, Short.MAX_VALUE))
        );
        panelBookLayout.setVerticalGroup(
            panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBookLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBookLayout.createSequentialGroup()
                        .addComponent(lblBook1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblBook2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLink2))
                        .addGap(18, 18, 18)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblBook3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblLink3))
                        .addGap(18, 18, 18)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblLink4)
                            .addComponent(lblBook4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelBookLayout.createSequentialGroup()
                                .addComponent(lblBook5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(81, 81, 81)
                                .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnAdd)
                                    .addComponent(btnRemove)
                                    .addComponent(btnBack)))
                            .addComponent(lblLink5)))
                    .addComponent(lblLink1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
        );

        lblLink1.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){
                lblLink1.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e){
                lblLink1.setForeground(Color.BLACK);
            }
        });
        lblLink2.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){
                lblLink2.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e){
                lblLink2.setForeground(Color.BLACK);
            }
        });
        lblLink3.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){
                lblLink3.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e){
                lblLink3.setForeground(Color.BLACK);
            }
        });
        lblLink4.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){
                lblLink4.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e){
                lblLink4.setForeground(Color.BLACK);
            }
        });
        lblLink5.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){
                lblLink5.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e){
                lblLink5.setForeground(Color.BLACK);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelBook, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBookFrame(user).setVisible(true);
            }
        });
        this.dispose();

    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        /*
        This button scans user and book file 
        Removes chosen book from user and adds it back into book file
        Then displays the changes
         */
        ArrayList<Book> bookArr = new ArrayList<>();
        String[] arr = {"", "", "", "", ""};
        boolean[] bool = {false, false, false, false, false};

        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File bookFile = new File("Book.txt");
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));

                int choice = Integer.parseInt(JOptionPane.showInputDialog("Which Book will you remove"));

                Scanner scBook = new Scanner(bookFile);//Book file saved in bookArr
                while (scBook.hasNext()) {
                    Scanner sc = new Scanner(scBook.nextLine());
                    Book newBook = new Book(sc.nextLine());
                    bookArr.add(newBook);
                }
                if (removeQueue(arrList.get(choice - 1).getBook())) {//Does changes
                    bookArr.add(arrList.get(choice - 1));
                }
                arrList.remove(choice - 1);
                FileWriter fwBook = new FileWriter(bookFile);//Saves changes in book file
                for (int j = 0; j < bookArr.size(); j++) {
                    fwBook.write(bookArr.get(j).getBook());
                    fwBook.write("\n");
                }
                fwBook.close();

                FileWriter fwFile = new FileWriter(userFile);//Saves changes in user file
                for (int i = 0; i < arrList.size(); i++) {
                    fwFile.write(arrList.get(i).toString());
                    fwFile.write("\n");
                }
                fwFile.close();

                Scanner scReset = new Scanner(userFile);
                for (int i = 0; i < 5 && scReset.hasNext(); i++) {//Display

                    Scanner sc = new Scanner(scReset.nextLine()).useDelimiter("#");
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    String uri = sc.next();
                    Book book = new Book(strbook, date, pay,uri);
                    arr[i] = book.getBook() + "     Due: " + book.getDate();
                    bool[i] = book.isPayment();
                    sc.close();

                }
                scReset.close();

                lblBook1.setText("1: " + arr[0]);
                lblBook2.setText("2: " + arr[1]);
                lblBook3.setText("3: " + arr[2]);
                lblBook4.setText("4: " + arr[3]);
                lblBook5.setText("5: " + arr[4]);

                lblLink1.setVisible(bool[0]);
                lblLink2.setVisible(bool[1]);
                lblLink3.setVisible(bool[2]);
                lblLink4.setVisible(bool[3]);
                lblLink5.setVisible(bool[4]);
                
                setLinks(bool);

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrontFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnRemove;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblBook1;
    private javax.swing.JLabel lblBook2;
    private javax.swing.JLabel lblBook3;
    private javax.swing.JLabel lblBook4;
    private javax.swing.JLabel lblBook5;
    private javax.swing.JLabel lblLink1;
    private javax.swing.JLabel lblLink2;
    private javax.swing.JLabel lblLink3;
    private javax.swing.JLabel lblLink4;
    private javax.swing.JLabel lblLink5;
    private javax.swing.JPanel panelBook;
    // End of variables declaration//GEN-END:variables

}
