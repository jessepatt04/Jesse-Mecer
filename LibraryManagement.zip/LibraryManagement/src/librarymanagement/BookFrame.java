//Jesse A P
package librarymanagement;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static librarymanagement.LibraryManagement.getConn;

/**
 *
 * @author Studio20-10
 */
public final class BookFrame extends javax.swing.JFrame {

    private static Connection conn;
    private final User user;
    private final ArrayList<Book> arrList = new ArrayList<>();
    private final ArrayList<Queue> queueList = new ArrayList<>();

    /**
     * Creates new form BookFrame
     */
    public BookFrame(User user) {
        this.user = user;
        BookFrame.conn = getConn();//Static Connection
        initComponents();
        panelBook.setBackground(user.getUserColor());
        validateDueDate();//Checks due date
        setLabels();//Sets label to display hired books
    }

    public void validateDueDate() {
        ArrayList<Book> bookArr = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));
                File bookFile = new File("Book.txt");

                if (!userFile.exists()) {//Sets up new txt file if it dosent exist
                    FileWriter fwNew = new FileWriter(userFile);
                    fwNew.close();
                }

                Scanner scFile = new Scanner(userFile);

                for (int i = 0; i < 5 && scFile.hasNext(); i++) {

                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");//Scans user file stores in arrList
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    Book bookObj = new Book(strbook, date, pay);
                    arrList.add(bookObj);
                    sc.close();

                    if (bookObj.getDate().isBefore(LocalDate.now())) {//Checks date
                        JOptionPane.showMessageDialog(null, bookObj.getBook() + " was removed for out of date reasoning " + bookObj.getDate());
                        Scanner scBook = new Scanner(bookFile);

                        while (scBook.hasNext()) {//Scans book file stores in bookArr
                            Scanner scLine = new Scanner(scBook.nextLine());
                            Book newBook = new Book(scLine.nextLine());
                            bookArr.add(newBook);
                        }
                        scBook.close();

                        bookArr.add(arrList.get(i));//Adds to library and removes from user file 
                        arrList.remove(i);

                        FileWriter fwBook = new FileWriter(bookFile);
                        for (int j = 0; j < bookArr.size(); j++) {//Writes changes into book File
                            fwBook.write(bookArr.get(j).getBook());
                            fwBook.write("\n");
                        }
                        fwBook.close();

                        FileWriter fwFile = new FileWriter(userFile);
                        for (int j = 0; j < arrList.size(); j++) {//Writes changes into user file
                            fwFile.write(arrList.get(j).toString());
                            fwFile.write("\n");
                        }
                        fwFile.close();

                    }
                    arrList.clear();//Clears user list 
                }

                scFile.close();

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setLabels() {
        String[] arr = {"", "", "", "", ""};

        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));

                Scanner scFile = new Scanner(userFile);

                for (int i = 0; i < 5 && scFile.hasNext(); i++) {

                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");
                    //Scans user file and stores in a String array
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    Book bookObj = new Book(strbook, date, pay);
                    arr[i] = bookObj.getBook() + "     Due: " + bookObj.getDate();
                    sc.close();

                }

                lblBook1.setText("1: " + arr[0]);//Display
                lblBook2.setText("2: " + arr[1]);
                lblBook3.setText("3: " + arr[2]);
                lblBook4.setText("4: " + arr[3]);
                lblBook5.setText("5: " + arr[4]);

                scFile.close();

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean removeQueue(String removeQue) {
        int test = 0;
        boolean found = false;
        boolean mainBoolean = false;
        File queueFile = new File("Queue.txt");
        ArrayList<Book> newArrList = new ArrayList<>();
        try {
            Scanner scQueue = new Scanner(queueFile);

            while (scQueue.hasNext()) {//Scan que file and stores in queuelist
                Scanner sc = new Scanner(scQueue.nextLine()).useDelimiter("#");
                String bookName = sc.next();
                queueList.add(new Queue(bookName));
                while (sc.hasNext()) {
                    String temp = sc.next();
                    queueList.get(test).addQueue(temp);
                }
                test++;
                sc.close();
            }
            scQueue.close();

            for (int i = 0; i < queueList.size() && found == false; i++) {
            //Loops queuelist to find the book user is removing
                if (queueList.get(i).getBook().equals(removeQue)) {
                    found = true;
                    if (!queueList.get(i).getPeopleList().isEmpty()) {//If there is a que
                        File newUserFile = new File("TextFiles\\" + queueList.get(i).getFirstQueue() + ".txt");
                        try {
                            Scanner scFile = new Scanner(newUserFile);
                            while (scFile.hasNext()) {//Scan through the file of the first person in queue
                                Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");//Scans user file stores in arrList
                                String strbook = sc.next();
                                DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                LocalDate date = LocalDate.parse(sc.next(), format);
                                boolean pay = sc.nextBoolean();
                                Book bookObj = new Book(strbook, date, pay);
                                newArrList.add(bookObj);//Strores in newArrList
                                sc.close();
                            }
                            scFile.close();

                            if (newArrList.size() < 5) {//If they have space they will get the book
                                newArrList.add(new Book(queueList.get(i).getBook()));
                            } else {//If not they are removed from que and tries again
                                queueList.get(i).removeQueue();
                                FileWriter fwQueue = new FileWriter(queueFile);
                                for (int j = 0; j < queueList.size(); j++) {
                                    fwQueue.write(queueList.get(j).toString());
                                    fwQueue.write("\n");
                                }
                                fwQueue.close();
                                queueList.clear();
                                return removeQueue(removeQue);//Recursion to repeat method until decision is made
                            }

                            FileWriter fwFile = new FileWriter(newUserFile);//Saves first person in que change
                            for (int j = 0; j < newArrList.size(); j++) {
                                fwFile.write(newArrList.get(j).toString());
                                fwFile.write("\n");
                            }
                            fwFile.close();
                            newArrList.clear();
                        } catch (FileNotFoundException e) {
                            System.out.println("No File");
                        } catch (IOException e) {
                            System.out.println("IO Error");
                        }
                        queueList.get(i).removeQueue();//Once first person in que gets book they are removed from que
                    } else {//If no que remove book from que and return true to add book to library
                        queueList.remove(i);
                        mainBoolean = true;
                    }
                }
            }
            FileWriter fwQueue = new FileWriter(queueFile);//Save changes of que
            for (int i = 0; i < queueList.size(); i++) {
                fwQueue.write(queueList.get(i).toString());
                fwQueue.write("\n");
            }
            fwQueue.close();
            queueList.clear();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (DuplicateUserException ex) {
            Logger.getLogger(AddBookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        return mainBoolean;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBook = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblBook1 = new javax.swing.JLabel();
        lblBook2 = new javax.swing.JLabel();
        lblBook3 = new javax.swing.JLabel();
        lblBook4 = new javax.swing.JLabel();
        lblBook5 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelBook.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setText("Books you own");

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBookLayout = new javax.swing.GroupLayout(panelBook);
        panelBook.setLayout(panelBookLayout);
        panelBookLayout.setHorizontalGroup(
            panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBookLayout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addComponent(jLabel1)
                .addContainerGap(187, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBookLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnBack)
                .addContainerGap())
            .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelBookLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(lblBook5, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                        .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblBook4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                            .addComponent(lblBook3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                            .addComponent(lblBook2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelBookLayout.createSequentialGroup()
                                .addComponent(btnAdd)
                                .addGap(18, 18, 18)
                                .addComponent(btnRemove))
                            .addComponent(lblBook1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 430, Short.MAX_VALUE)))
                    .addContainerGap(18, Short.MAX_VALUE)))
        );
        panelBookLayout.setVerticalGroup(
            panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBookLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 297, Short.MAX_VALUE)
                .addComponent(btnBack)
                .addContainerGap())
            .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelBookLayout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(lblBook1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(lblBook2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(lblBook3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(lblBook4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(lblBook5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                    .addGroup(panelBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnAdd)
                        .addComponent(btnRemove))
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelBook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddBookFrame(user).setVisible(true);
            }
        });
        this.dispose();

    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        /*
        This button scans user and book file 
        Removes chosen book from user and adds it back into book file
        Then displays the changes
         */
        ArrayList<Book> bookArr = new ArrayList<>();
        String[] arr = {"", "", "", "", ""};

        try {
            PreparedStatement pstmt = conn.prepareStatement("Select BooksFile From LibraryTable Where Username = ?");
            pstmt.setString(1, user.getName());

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                File bookFile = new File("Book.txt");
                File userFile = new File("TextFiles\\" + rs.getString("BooksFile"));

                Scanner scFile = new Scanner(userFile);//User file saved in arrList
                while (scFile.hasNext()) {
                    Scanner sc = new Scanner(scFile.nextLine()).useDelimiter("#");
                    String book = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    Book newBook = new Book(book, date, pay);
                    arrList.add(newBook);
                }
                scFile.close();
                int choice = Integer.parseInt(JOptionPane.showInputDialog("Which Book will you remove"));

                Scanner scBook = new Scanner(bookFile);//Book file saved in bookArr
                while (scBook.hasNext()) {
                    Scanner sc = new Scanner(scBook.nextLine());
                    Book newBook = new Book(sc.nextLine());
                    bookArr.add(newBook);
                }
                if (removeQueue(arrList.get(choice - 1).getBook())) {//Does changes
                    bookArr.add(arrList.get(choice - 1));
                }
                arrList.remove(choice - 1);
                FileWriter fwBook = new FileWriter(bookFile);//Saves changes in book file
                for (int j = 0; j < bookArr.size(); j++) {
                    fwBook.write(bookArr.get(j).getBook());
                    fwBook.write("\n");
                }
                fwBook.close();

                FileWriter fwFile = new FileWriter(userFile);//Saves changes in user file
                for (int i = 0; i < arrList.size(); i++) {
                    fwFile.write(arrList.get(i).toString());
                    fwFile.write("\n");
                }
                fwFile.close();
                arrList.clear();

                Scanner scReset = new Scanner(userFile);
                for (int i = 0; i < 5 && scReset.hasNext(); i++) {//Display

                    Scanner sc = new Scanner(scReset.nextLine()).useDelimiter("#");
                    String strbook = sc.next();
                    DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate date = LocalDate.parse(sc.next(), format);
                    boolean pay = sc.nextBoolean();
                    Book book = new Book(strbook, date, pay);
                    arr[i] = book.getBook() + "     Due: " + book.getDate();
                    sc.close();

                }
                scReset.close();

                lblBook1.setText("1: " + arr[0]);
                lblBook2.setText("2: " + arr[1]);
                lblBook3.setText("3: " + arr[2]);
                lblBook4.setText("4: " + arr[3]);
                lblBook5.setText("5: " + arr[4]);

            } else {
                lblBook1.setText("Empty");
            }
        } catch (SQLException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(BookFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrontFrame(user).setVisible(true);
            }
        });
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnRemove;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblBook1;
    private javax.swing.JLabel lblBook2;
    private javax.swing.JLabel lblBook3;
    private javax.swing.JLabel lblBook4;
    private javax.swing.JLabel lblBook5;
    private javax.swing.JPanel panelBook;
    // End of variables declaration//GEN-END:variables

}
