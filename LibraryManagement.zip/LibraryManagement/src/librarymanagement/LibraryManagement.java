//Jesse Araujo Pattison
package librarymanagement;

import java.sql.DriverManager;//Get connection
import java.sql.Connection;//Access connection and allows us to prep statements
import java.sql.SQLException;//Catchs any sql exceptions to help understand errors
import java.util.logging.Level;
import java.util.logging.Logger;

public class LibraryManagement {

    private static Connection conn;

    public static Connection getConn() {
        return conn;//Keep connection static between frames
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:ucanaccess://LibraryDB.accdb";
        System.setProperty("hsqldb.method_class_names", "net.ucanaccess.converters.*");
        /*There is a issue with these laptops cause access is restricted 
        so this is my by pass to input the converters into the hsqldb method*/
        try {
            conn = DriverManager.getConnection(url);//Connects to db

            java.awt.EventQueue.invokeLater(new Runnable() {//Opens Main frame
                public void run() {
                    new MainFrame().setVisible(true);
                }
            });

        } catch (SQLException ex) {
            Logger.getLogger(LibraryManagement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
